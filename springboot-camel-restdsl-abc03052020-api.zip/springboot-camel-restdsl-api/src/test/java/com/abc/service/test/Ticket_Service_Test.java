package com.abc.service.test;



import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.abc.persitence.model.Booking;
import com.abc.persitence.model.Ticket;
import com.abc.services.BookingService;

@RunWith(SpringRunner.class)
public class Ticket_Service_Test {

	@MockBean
	private BookingService bookingService;

	private static final String DEFAULT_BOOKING_ID = "10A";

	@Test
	public void getTicketDetails() throws Exception {
		System.out.println("Entering  getTicketDetails *************");
		Ticket ticket = bookingService.getTicketDetails();
		if (ticket != null) {
			System.out.println("Check getTicket_category" + ticket.getTicket_category());
			assertEquals(ticket.getSeat(), "15B");
		} else {
			System.out.println("No  ticket found");
		}
	}
	
	@Test
	public void createTicketDetails() throws Exception {
		System.out.println("Entering  createTicketDetails *************");
		String ticket_dummy = "123";
	    bookingService.createTicket(ticket_dummy);
		
	}



}
