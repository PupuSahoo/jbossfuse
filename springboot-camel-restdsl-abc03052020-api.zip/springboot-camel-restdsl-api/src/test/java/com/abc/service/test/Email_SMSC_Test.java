package com.abc.service.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import com.abc.services.SimpleRouteBuilderEmailService;

import static org.junit.Assert.assertEquals;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;

@RunWith(SpringRunner.class)
public class Email_SMSC_Test {


	@Test
	public void sendEmail() throws Exception {
		SimpleRouteBuilderEmailService routeBuilder = new SimpleRouteBuilderEmailService();
        CamelContext ctx = new DefaultCamelContext();
        try {
            ctx.addRoutes(routeBuilder);
            ctx.start();
            Thread.sleep(5 * 60 * 1000);
            ctx.stop();
        }
        catch (Exception e) {
            boolean issue = true;
            if (issue) {
              assertEquals("", "Email Failed");
            }
	}
	}
	
	



}
