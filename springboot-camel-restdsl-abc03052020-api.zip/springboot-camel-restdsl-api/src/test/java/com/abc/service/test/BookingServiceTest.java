package com.abc.service.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.abc.persitence.model.Booking;
import com.abc.services.BookingService;

@RunWith(SpringRunner.class)
public class BookingServiceTest {

	@MockBean
	private BookingService bookingService;

	private static final String DEFAULT_BOOKING_ID = "10A";

	@Test
	public void getExistingCustomer_BookingInfoymation() throws Exception {
		System.out.println("Entering  givenExistingCustomer_BookingInfoymation *************");
		Booking customers = bookingService.getBookingDetail("10A");
		if (customers != null) {
			System.out.println("Check Destination" + customers.getDestination());
			assertEquals(customers.getDestination(), "Bhubaneswar");
		} else {
			System.out.println("No  Cust found");
		}
	}

	@Test
	public void getAllExistingCustomer_BookingInformation() throws Exception {
		System.out.println("Entering  givenExistingCustomer_BookingInfoymation *************");
		List<Booking> customers = bookingService.allCustBookings();
		if (customers != null) {
			for (Booking eachbook : customers) {
				System.out.println("Check Destination" + eachbook.getDestination());
				assertEquals(eachbook.getDestination(), "Bhubaneswar");
			}
		} else {
			System.out.println("No  Cust found");
		}

	}
	
	@Test
	public void test_delete_booking() throws Exception {
		System.out.println("Entering  test_delete_booking *************");
		String dummy_id = null;
		Booking booking  = bookingService.getBookingDetail(dummy_id);
		if (booking != null) {
			
				assertEquals(booking.getDestination(), "Bhubaneswar");
			}
		 else {
			System.out.println("No  Booking  found");
		}

	}

}
