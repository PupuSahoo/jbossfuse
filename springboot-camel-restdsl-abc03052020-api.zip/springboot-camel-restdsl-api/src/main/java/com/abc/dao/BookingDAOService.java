package com.abc.dao;

import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.xml.ws.Response;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.abc.persitence.model.Booking;


@Repository
@Transactional
public class BookingDAOService {
		
	@PersistenceContext
	private EntityManager entityManager;
	
	public long insert(Booking booking){
		entityManager.persist(booking);
		return booking.getBook_id();
	}
	
	public void deleteAllBookings() {
    	List<Booking> bookings = (List<Booking>) getAll(new HashMap<String, String>());
    	for (Booking booking : bookings) {
    		deleteBooking(booking.getBook_id());
    	}
       
    }
	
	public Object getAll(HashMap<String, String> queryParameters) {
        final CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        Object allbooking = null;
        //to DO
		return allbooking;
    }
	
	/**
     * <p>
     * Delete a booking by id
     * </p>
     * @param id
     * @return
     */

    public void deleteBooking(Long id) {
        Booking booking = getEntityManager().find(Booking.class, id);
        
        getEntityManager().remove(booking);
        //TODO

    }
    
    public EntityManager getEntityManager() {
        return entityManager;
    }

}


