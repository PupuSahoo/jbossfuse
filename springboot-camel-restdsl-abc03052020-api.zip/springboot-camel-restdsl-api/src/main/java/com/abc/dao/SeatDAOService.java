package com.abc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.abc.persitence.model.Booking;
import com.abc.persitence.model.Seat;
import com.abc.persitence.model.Ticket;


@Repository
@Transactional
public class SeatDAOService {
		
	@PersistenceContext
	private EntityManager entityManager;
	
	public long insert(Seat seat){
		entityManager.persist(seat);
		return seat.getId();
	}
	
	//Other  methods  will be added
}


