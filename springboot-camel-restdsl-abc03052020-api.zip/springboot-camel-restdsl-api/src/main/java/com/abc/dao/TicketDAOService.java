package com.abc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.abc.persitence.model.Booking;
import com.abc.persitence.model.Ticket;


@Repository
@Transactional
public class TicketDAOService {
		
	@PersistenceContext
	private EntityManager entityManager;
	
	public long insert(Ticket ticket){
		entityManager.persist(ticket);
		return ticket.getTicket_id();
	}
}


