package com.abc.persitence.model;

public class Seat {
	
	private Long id;
	private String seat_no;
	
	public Seat (Long id,String seat_no) {
		this.id = id;
		this.seat_no =seat_no;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSeat_no() {
		return seat_no;
	}
	public void setSeat_no(String seat_no) {
		this.seat_no = seat_no;
	}
	
	

}
