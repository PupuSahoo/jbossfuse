package com.abc.persitence.model;

import java.io.Serializable;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@SuppressWarnings("serial")
@Entity
public class Ticket  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Ticket(Long ticket_id,float ticket_price,String ticket_category,Seat seat) {
		this.ticket_id = ticket_id;
		this.ticket_price = ticket_price;
		this.ticket_category = ticket_category;
		this.seat = seat;
	}
	
	
	@Id
    @GeneratedValue(strategy = IDENTITY)
    private Long ticket_id;	
	private float ticket_price;
	private String ticket_category;
	@NotNull
    private Seat seat;
	
	public Long getTicket_id() {
		return ticket_id;
	}
	public void setTicket_id(Long ticket_id) {
		this.ticket_id = ticket_id;
	}
	public float getTicket_price() {
		return ticket_price;
	}
	public void setTicket_price(float ticket_price) {
		this.ticket_price = ticket_price;
	}
	public String getTicket_category() {
		return ticket_category;
	}
	public void setTicket_category(String ticket_category) {
		this.ticket_category = ticket_category;
	}
	public Seat getSeat() {
		return seat;
	}
	public void setSeat(Seat seat) {
		this.seat = seat;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	


}
