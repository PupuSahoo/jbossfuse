package com.abc.persitence.model;

public class Booking {
	
	public Booking(long book_id,String origin, String destination,String seatdetails,String preference) {
		this.book_id = book_id;
		this.origin = origin;
		this.destination = destination;
		this.seatdetails = seatdetails;
		this.preference = preference;
		
	}

	private long book_id;
	public long getBook_id() {
		return book_id;
	}

	public void setBook_id(long book_id) {
		this.book_id = book_id;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getSeatdetails() {
		return seatdetails;
	}

	public void setSeatdetails(String seatdetails) {
		this.seatdetails = seatdetails;
	}

	public String getPreference() {
		return preference;
	}

	public void setPreference(String preference) {
		this.preference = preference;
	}

	private String origin;
	private String destination;
	private String seatdetails;
	private String preference;

	

}
