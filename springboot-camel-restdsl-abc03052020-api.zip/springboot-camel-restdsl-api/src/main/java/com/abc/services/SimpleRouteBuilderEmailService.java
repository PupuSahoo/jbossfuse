package com.abc.services;

import org.apache.camel.builder.RouteBuilder;

public class SimpleRouteBuilderEmailService extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		from("file:C:/inputFolder?noop=true").doTry().setHeader("subject", simple("JavaInUse Invitation111"))
				.setHeader("to", simple("javainuse@gmail.com,testouthworking@gmail.com"))
				.to("smtps://smtp.gmail.com:465?username=testcamelsmtp@gmail.com&password=ABC@123");
	}
}