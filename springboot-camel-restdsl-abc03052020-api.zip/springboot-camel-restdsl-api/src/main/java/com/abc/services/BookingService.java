package com.abc.services;


import java.util.List;

import com.abc.persitence.model.Booking;
import com.abc.persitence.model.Ticket;


public interface BookingService {

    List<Booking> allCustBookings();
    Booking getBookingDetail(final String id);    
    Ticket getTicketDetails();   
    public void createTicket(String booking_id);

}