package com.abc.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

import com.abc.persitence.model.Booking;
import com.abc.persitence.model.Seat;
import com.abc.persitence.model.Ticket;

@Service
public class BookingServiceImpl implements BookingService{
	
	private HashMap<String, Booking> bookingMap ;

    
	public BookingServiceImpl() {
	final AtomicLong counter = new AtomicLong();
    final Booking bookingOne = new Booking(counter.incrementAndGet(),"Chennai", "Bhubaneswar", "Seat-14B","veg-combo");
    final Booking bookingTwo = new Booking(counter.incrementAndGet(),"Chennai", "Mumbai", "Seat-14C","veg-combo");
    final Booking bookingThree = new Booking(counter.incrementAndGet(),"Chennai", "newDelhi", "Seat-12B","veg-combo");

    bookingMap.put("10A",bookingOne);
    bookingMap.put("20B", bookingTwo);
    bookingMap.put("30C", bookingThree);
	}

	@Override
	public List<Booking> allCustBookings() {
		return new ArrayList<>(bookingMap.values());
	}

	@Override
	public Booking getBookingDetail(String booking_id) {
		System.out.println("Check what got from here  &&&&& "+bookingMap.get(booking_id));
		return bookingMap.get(booking_id);
	}

	@Override
	public Ticket getTicketDetails() {
		// Call jpa  ticket details  passing booking id
		Seat seat = new Seat(new AtomicLong().addAndGet(2),"15");
		final AtomicLong counter = new AtomicLong();
		final Ticket oneTicket = new Ticket(counter.incrementAndGet(),100,"Economy",seat);
		return oneTicket ;
	}

	@Override
	public void createTicket(String booking_id) {
		// TODO Auto-generated method stub
		
		
	}

}
