package com.booking.start.boot;

import java.util.concurrent.atomic.AtomicLong;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import com.abc.persitence.model.Booking;

@SpringBootApplication
public class SpringbootCamelRestdslApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCamelRestdslApiApplication.class, args);
	}

	@Component
	class BookingRoute extends RouteBuilder {

		@Override
		public void configure() {
			restConfiguration()
			.component("servlet")
			.bindingMode(RestBindingMode.json);

			rest("/booking").produces("application/json")
			.get("/hello/{name}")
			.route().transform().simple("Hello ${header.name}, Welcome to ABC airlines")
			.endRest()
			.get("/records/{name}").to("direct:records");
			from("direct:records")
			.process(new Processor() {

				final AtomicLong counter = new AtomicLong();

				@Override
				public void process(Exchange exchange) throws Exception {
					final String name = exchange.getIn().getHeader("name",String.class);
					exchange.getIn().setBody(new Booking(counter.incrementAndGet(),name,"Booking air ticket","Seat 14B","veg-meal"));
				}
			});
		}
	}
}

//http://localhost:8080/booking/hello/Mano
//http://localhost:8080/booking/records/Sahoo