package com.booking.start.boot;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;


@SpringBootApplication
public class SpringbootCamelRestdslApiApplicationEmail {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCamelRestdslApiApplicationEmail.class, args);
	}

	@Component
	class EmailRoute extends RouteBuilder {
		@Override
		public void configure() throws Exception {
			from("file:C:/inputFolder?noop=true").doTry().setHeader("subject", simple("Booking Update from ABC"))
					.setHeader("to", simple("abc@gmail.com,cust@gmail.com"))
					.to("smtps://smtp.gmail.com:465?username=testcamelsmtp@gmail.com&password=ABC@123");
		}


	}
}

